import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {Action} from '@ngrx/store';

import * as userAction from './user.actions';
import {catchError, map, mergeMap, Observable, of} from 'rxjs';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class UserEffects {

  constructor(
    private actions$: Actions,
    private http: HttpClient,
  ) {
  }

  @Effect()
  loadUser$: Observable<Action> = this.actions$.pipe(
    ofType(userAction.UserActionTypes.LoadUsers),
    mergeMap(
      action => this.http.get<any>('https://jsonplaceholder.typicode.com/posts').pipe(
        map(user => (new userAction.LoadUsersSuccess({data: user}))),
        catchError(err => of(new userAction.LoadUsersFailure({error: err})))
      )
    )
  );
}
